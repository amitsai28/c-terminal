#ifndef COMMAND
#define COMMAND

void ExecuteCommand(char command[],char *token,const char delemiter[]);

#endif
