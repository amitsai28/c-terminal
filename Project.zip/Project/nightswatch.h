#ifndef NIGHTSWATCH
#define NIGHTSWATCH

void handler(int signum);
void ExecuteNightsWatch(char *token,const char delemiter[]);

#endif
