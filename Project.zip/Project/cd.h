#ifndef CD
#define CD

void ExecuteCD(char *token,const char delemiter[]);

#endif
