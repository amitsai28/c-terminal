#ifndef ECHO
#define ECHO

void ExecuteECHO(char command[],char *token,const char delemiter[]);

#endif
