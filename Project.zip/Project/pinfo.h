#ifndef PINFO
#define PINFO

void ConvertPID(char stringpid[],int pid);
void ExecutePINFO(char *token,const char delemiter[]);

#endif
