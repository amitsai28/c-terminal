#ifndef EXECUTE
#define EXECUTE

int ExecuteOtherCommands(char *token,const char delemiter[]);
void childhandler(int signum);

#endif
