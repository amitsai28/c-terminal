#ifndef LS
#define LS

void ExecuteSimpleLS(char *token,int flag);
void PrintLongListing(char temp[],char name[],int len,int file);
void ExecuteLongLS(char *token,int flag);
void ExecuteLS(char *token,const char delemiter[]);

#endif
