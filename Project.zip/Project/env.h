#ifndef ENV
#define ENV

void ExecuteEnv(char *token, const char delemiter[] ,int flag);

#endif
