#ifndef PIPE
#define PIPE

void ExecutePipe(char command[],char * token,const char delemiter[]);

#endif
